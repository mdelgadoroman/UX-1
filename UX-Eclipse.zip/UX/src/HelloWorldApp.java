import org.rosuda.REngine.*;
import org.rosuda.REngine.Rserve.*;

public class HelloWorldApp {
	public static void main(String[] args) throws RserveException, REXPMismatchException {
		 try {
	            RConnection c = new RConnection();// make a new local connection on default port (6311)
	            REXP x = c.eval("try(myLabellingFunction)}, silent=TRUE)");
	            System.out.println(x.asString());
	            /*if (c.isConnected())
	            	System.out.println(1);
	            else
	            	System.out.println(0);*/
	            double d[] = c.eval("rnorm(10)").asDoubles();
	       
	            org.rosuda.REngine.REXP x0 = c.eval("R.version.string");
	            System.out.println(x0.asString());
	} catch (REngineException e) {}
	            //manipulation
		 
		 //REXP r = .eval("median(1:4)");
	}
}
